<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styel.css">
</head>
<body>
    <div class="conteiner">
    <form method="post">
    <input type="number" name="n1" placeholder="Insira a sua primeira nota"><br>
    <input type="number" name="n2" placeholder="Insira a sua segunda nota"><br>
    <input type="number" name="n3" placeholder="Insira a sua terceira nota"><br><br>
    <input type="submit" name="enviar"><br>
    </form>
   
    <?php
if (isset($_POST["n1"]) && isset($_POST["n2"]) && isset($_POST["n3"])) {

    $nota1 = $_POST["n1"];
    $nota2 = $_POST["n2"];
    $nota3 = $_POST["n3"];
   
    if(($nota1+$nota2+$nota3)/3 >= 7){
echo "<br>aprovado meu tuffo";
    }else{
        echo "<br>reprovado beta";
    }
}
?>
 </div>
</body>
</html>