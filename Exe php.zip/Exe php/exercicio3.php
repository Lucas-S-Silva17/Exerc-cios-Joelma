<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styel.css">
</head>
<body>
    <div class="conteiner">
    <form method="post">
    <input type="number" name="temp" placeholder="Insira a temperatura em °C"><br>
        <input type="number" name="temp1" placeholder="Insira a temperatura em °C"><br>
    <input type="submit" name="enviar"><br>
    </form>
   
    <?php
if (isset($_POST["temp"]) & isset($_POST["temp1"])) {

    $temp = $_POST["temp"];
    $temp1 = $_POST["temp1"];

    if(($temp1*$temp1)/$temp < 18.5){
echo "congelante";
    }elseif($temp>=0 & $temp<15){
       echo"muito frio";
    }elseif($temp>=15 & $temp<25){
       echo"razoável";
    }else{
       echo"Quente";
    }
}
?>
 </div>
</body>
</html>