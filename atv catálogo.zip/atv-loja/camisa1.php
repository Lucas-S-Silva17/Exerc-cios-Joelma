<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Produto</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>
    body {
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #cdb79e;
    }

    /* HEADER */
    header {
        background-color: #7b6759;
        padding: 15px 30px;
        color: #9ed0ff;
        font-size: 16px;
        font-weight: bold;
        display: flex;
        height: 10vh;
    }

    /* CARD CENTRAL */
    .card {
        background: #d8c3a5;
        width: 300px;
        margin: 50px auto;
        padding: 25px;
        border-radius: 20px;
        text-align: center;
    }

    /* IMAGEM */
    .card img {
        width: 220px;
        height: 220px;
        object-fit: contain;
        background-color: #7fa2c7;
        border-radius: 30px;
        border: 6px solid #7b6759;
        padding: 15px;
        margin-bottom: 15px;
    }

    /* TÍTULO */
    .card h2 {
        color: #6b5a4d;
    }

    /* TEXTO */
    .card p {
        color: #6b5a4d;
        font-size: 18px;
    }

    /* CORES */
    .cores button {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        border: 3px solid #7b6759;
        margin: 5px;
        cursor: pointer;
    }

    /* SUAS CORES */
    .purple {
        background: purple;
    }

    .orange {
        background: orange;
    }

    .green {
        background: green;
    }

    .red {
        background: red;
    }

    /* TAMANHOS */
    .tamanhos button {
        margin: 5px;
        padding: 8px 12px;
        border-radius: 8px;
        border: 2px solid #7b6759;
        background: white;
        cursor: pointer;
    }

    /* BOTÃO PRINCIPAL */
    form button,
    .card>button {
        margin-top: 15px;
        padding: 10px;
        width: 100%;
        background-color: #7b6759;
        color: white;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        font-weight: bold;
    }

    /* MENSAGEM PHP */
    .msg {
        margin-top: 15px;
        background: #d4edda;
        padding: 10px;
        border-radius: 10px;
        color: #2e6b3f;
    }

    .logo {
        height: 10vh;
        padding: 1%;
        display: flex;
        align-items: center;

    }

    .logo:hover {
        transition-duration: 0.5s;
        transform: rotate(360deg);
        color: #84ADD7;
        display: flex;

    }

    .cabecalho {
        padding-left: 3%;
        position: relative;
        z-index: 10;
    }

    .texto {
        background-color: #7B675B;
        display: flex;
        color: #84ADD7;
        font-size: x-large;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        text-align: center;
        align-items: center;
    }
    button:hover {
    transform: scale(1.1);
    box-shadow: 0 0 10px rgba(0,0,0,0.3);
}
</style>

<body>
    <script>
        let corAtual = "purple";
        let lado = "frente";
        let tamanhoSelecionado = "";

        function trocarCor(cor) {
            corAtual = cor;
            atualizarImagem();
            document.getElementById("cor").value = cor;
        }

        function atualizarImagem() {
            document.getElementById("produto").src =
                "images/" + corAtual + "_" + lado + ".png";
        }

        function selecionarTamanho(tam) {
            "images/" + corAtual + "_" + lado + ".png"
            tamanhoSelecionado = tam;
            document.getElementById("tamanho").value = tam;
        }
        function girar() {
            lado = (lado === "frente") ? "costa" : "frente";
            atualizarImagem();
        }
    </script>


    <header>
        <div class="texto">
            <div class="cabecalho">
                <h1><b>Blashop</b></h1>
            </div>
            <img src="images/blastoise.png" alt="logo" class="logo" width="">
        </div>
    </header>

    <div class="card">
        <h2>Camiseta do gengar</h2>
        <img id="produto" src="images/purple_frente.png">
        <p>Selecione a Cor:</p>
        <div class="cores">
            <button onclick="trocarCor('purple')" class="purple"></button>
            <button onclick="trocarCor('orange')" class="orange"></button>
            <button onclick="trocarCor('green')" class="green"></button>
            <button onclick="trocarCor('red')" class="red"></button>
        </div>

        <p>Tamanho:</p>
        <div class="tamanhos">
            <button onclick="selecionarTamanho('P')" class="tamanho">P</button>
            <button onclick="selecionarTamanho('M')" class="tamanho">M</button>
            <button onclick="selecionarTamanho('G')" class="tamanho">G</button>
        </div>

        <button onclick="girar()">Girar</button>

        <form method="post">
            <input type="hidden" name="cor" id="cor">
            <input type="hidden" name="tamanho" id="tamanho">
            <button type="submit">Adicionar ao carrinho</button>
        </form>

        <?php
        if ($_POST) {
            echo "<div class='msg'>Pedido enviado! <br> Vestido " . $_POST['cor'] . " | Tamanho " . $_POST['tamanho'] . "</div>";
        }
        ?>

    </div>


</body>

</html>